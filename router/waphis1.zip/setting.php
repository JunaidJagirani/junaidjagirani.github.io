<?php

$namagrp = 'GRUP VIRAL 18+'; //Nama Grup

$fotogrp = 'https://i.ibb.co/zJ1ZrGH/1.png'; //Foto Grup

$linkgrp = 'https://www.effectiveratecpm.com/g3uitedub4?key=86b5e3b42e8d7eee86f7c9d753f856a1'; //Link Grup

?>

