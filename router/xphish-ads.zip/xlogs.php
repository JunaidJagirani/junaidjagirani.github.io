<?php
// Set timezone to Karachi
date_default_timezone_set('Asia/Karachi');

// Log files
$ilog_file = 'ilogs.txt';
$slog_file = 'slogs.txt';

// Read logs
$ilogs = file_exists($ilog_file) ? array_reverse(file($ilog_file)) : [];
$slogs = file_exists($slog_file) ? array_reverse(file($slog_file)) : [];
$total_ilogs = count($ilogs);
$total_slogs = count($slogs);
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>IP Logger</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"></script>
    <style>
        body { transition: 0.3s; }
        .tab { cursor: pointer; padding: 12px 20px; display: inline-block; border-radius: 25px; background: linear-gradient(45deg, #ff416c, #ff4b2b); color: white; font-weight: bold; margin: 5px; transition: transform 0.3s ease; border: none; outline: none; width: 100%; max-width: 200px; }
        .tab:hover { transform: scale(1.1); }
        .active { background: linear-gradient(45deg, #4b79a1, #283e51); }
        .content { display: none; }
        .table-container { margin-top: 20px; overflow-x: auto; }
        .dark-mode { background-color: #121212; color: white; }
        .light-mode { background-color: #f8f9fa; color: black; }
        .toggle-btn { cursor: pointer; padding: 10px 15px; border-radius: 20px; background: #007bff; color: white; border: none; }
        img.flag { width: 24px; height: 16px; margin-right: 5px; display: inline-block; }
        @media (max-width: 768px) {
            .tab { width: 100%; max-width: none; }
            .table-container { overflow-x: scroll; }
        }
    </style>
</head>
<body class="light-mode">
    <div class="container text-center mt-4">
        <h2>IP Logger</h2>
        <button onclick="toggleMode()" class="toggle-btn">Toggle Day/Night Mode</button>
        <p class="mt-2">Total Visitors (Index Page): <?= $total_ilogs ?> | Total Visitors (Step3 Page): <?= $total_slogs ?></p>
        <div class="d-flex flex-column flex-md-row justify-content-center">
            <button class="tab active" onclick="showTab('index_logs')">Index Page Logs</button>
            <button class="tab" onclick="showTab('step3_logs')">Step3 Page Logs</button>
        </div>
    </div>

    <div id="index_logs" class="content table-container container mt-4" style="display: block;">
        <h3 class="text-center">Index Page Logs</h3>
        <div class="table-responsive">
            <table class="table table-bordered table-striped">
                <thead class="table-dark"><tr><th>Date & Time</th><th>IP</th><th>Country</th><th>City</th><th>ISP</th><th>Device</th><th>User Agent</th></tr></thead>
                <tbody>
                <?php foreach ($ilogs as $log): ?>
                    <?php $parts = explode('|', $log);
                    if (count($parts) >= 6) {
                        list($date, $ip, $country, $country_code, $city, $isp, $device, $user_agent) = array_map('trim', $parts);

                        $date = trim($date); // Keep the logged format
 // Convert to 12-hour format
                        $flag_url = "https://flagcdn.com/w40/{$country_code}.png";
                    ?>
                    <tr>
                        <td><?= $date ?></td>
                        <td><?= $ip ?></td>
                        <td><img class='flag' src='<?= $flag_url ?>' alt='<?= $country ?>'> <?= $country ?></td>
                        <td><?= $city ?></td>
			<td><?= $isp ?></td>
                        <td><?= $device ?></td>
                        <td><?= $user_agent ?></td>
                    </tr>
                    <?php } ?>
                <?php endforeach; ?>
                </tbody>
            </table>
        </div>
    </div>

    <div id="step3_logs" class="content table-container container mt-4">
        <h3 class="text-center">Step3 Page Logs</h3>
        <div class="table-responsive">
            <table class="table table-bordered table-striped">
                <thead class="table-dark"><tr><th>Date & Time</th><th>IP</th><th>Country</th><th>City</th><th>ISP</th><th>Device</th><th>User Agent</th></tr></thead>
                <tbody>
                <?php foreach ($slogs as $log): ?>
                    <?php $parts = explode('|', $log);
                    if (count($parts) >= 6) {
                        list($date, $ip, $country, $country_code, $city, $isp, $device, $user_agent) = array_map('trim', $parts);
                        $date = trim($date); // Convert to 12-hour format
                        $flag_url = "https://flagcdn.com/w40/{$country_code}.png";

                    ?>
                    <tr>
                        <td><?= $date ?></td>
                        <td><?= $ip ?></td>
                        <td><img class='flag' src='<?= $flag_url ?>' alt='<?= $country ?>'> <?= $country ?></td>
                        <td><?= $city ?></td>
			<td><?= $isp ?></td>
                        <td><?= $device ?></td>
                        <td><?= $user_agent ?></td>
                    </tr>
                    <?php } ?>
                <?php endforeach; ?>
                </tbody>
            </table>
        </div>
    </div>

    <script>
        function showTab(tabId) {
            document.querySelectorAll('.content').forEach(el => el.style.display = 'none');
            document.getElementById(tabId).style.display = 'block';
            document.querySelectorAll('.tab').forEach(el => el.classList.remove('active'));
            document.querySelector(`[onclick="showTab('${tabId}')"]`).classList.add('active');
        }

        function toggleMode() {
            let body = document.body;
            body.classList.toggle("light-mode");
            body.classList.toggle("dark-mode");
        }
    </script>
</body>
</html>
